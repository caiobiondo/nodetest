package test.br.com.itau.jp7.orq.consumer;

import java.util.Collections;

import br.com.itau.cert.client.CertClientManager;
import br.com.itau.cert.client.enums.Environment;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import br.com.itau.ikafka.clients.consumer.IKafkaConsumerBuilder;
import io.confluent.kafka.serializers.KafkaAvroDeserializer;

import br.com.itau.kafka.avro.Example;

public class ConsumerApp {

	private static Logger logger = LoggerFactory.getLogger(Consumer.class.getName());

	public static void main(String[] args) {
		CertClientManager.Builder()
						.withCertClientUser("JP70001")
						.withCertClientPassword("kcert-password")
						.withEnvironment(Environment.SANDBOX)
						.withAppName("java-ikafka-producer-consumer-native")
						.withKeyStoreLocation("C:Usersrodnetoitauestrategiasrecupcredito-orquestradoracoesappJP70001")
						.withKeyStorePassword("gAAAAABgp8B2a7Z_thBIxM21p235iTknnSfbf4MDlejvcKFAGPcUcMU_ymz8kvk7GUk4JAlqONTKRLmMKGhzSzi2BPbgHGgMPg==")
						.withTrustStoreLocation("C:Usersrodnetoitauestrategiasrecupcredito-orquestradoracoesappJP70001.truststore.jks")
						.withTrustStorePassword("gAAAAABgp8B2a7Z_thBIxM21p235iTknnSfbf4MDlejvcKFAGPcUcMU_ymz8kvk7GUk4JAlqONTKRLmMKGhzSzi2BPbgHGgMPg==")
						.withCommunity("Teste")
						.withSigla("EA3")
						.build().run();

		Consumer<String, Example> consumer = IKafkaConsumerBuilder.<String, Example>newBuilder()
				.withBootstrapServers("kafka-events.dev.aws.cloud.ihf:31101")
				.withGroupId("consumer-group-id")
				.withEnableAutoCommit(false)
				.withAutoOffsetReset("earliest")
				.withKeyDeserializerClass(StringDeserializer.class.getName())
				.withValueDeserializerClass(KafkaAvroDeserializer.class.getName())
				.withFetchMinBytes(65536)
				.withIsolationLevel("read_committed")
				.withClientId("test-id")
				.withSslSecurityProtocol("SSL")
				.withSslKeystoreLocation("C:Usersrodnetoitauestrategiasrecupcredito-orquestradoracoesappJP70001")
				.withSslKeystorePassword("gAAAAABgp8B2a7Z_thBIxM21p235iTknnSfbf4MDlejvcKFAGPcUcMU_ymz8kvk7GUk4JAlqONTKRLmMKGhzSzi2BPbgHGgMPg==")
				.withSslKeyPassword("gAAAAABgp8B2a7Z_thBIxM21p235iTknnSfbf4MDlejvcKFAGPcUcMU_ymz8kvk7GUk4JAlqONTKRLmMKGhzSzi2BPbgHGgMPg==")
				.withSslTruststoreLocation("C:Usersrodnetoitauestrategiasrecupcredito-orquestradoracoesappJP70001.truststore.jks")
				.withSslTruststorePassword("gAAAAABgp8B2a7Z_thBIxM21p235iTknnSfbf4MDlejvcKFAGPcUcMU_ymz8kvk7GUk4JAlqONTKRLmMKGhzSzi2BPbgHGgMPg==")
				.withSchemaRegistryUrl("https://kafka-events-schema-registry.dev.aws.cloud.ihf:8082")
				.withSpecificAvroReader(true)
				.withSchemaRegistryReuseSslKeystoreConfigFromIKafka(true)
				.withSchemaRegistryReuseSslTruststoreConfigFromIKafka(true)
				.build();

		String topic = "recuperacao-de-credito-comando-enviar-distribuicao-escritorio-recuperacao-credito";

		consumer.subscribe(Collections.singleton(topic));

		logger.info("### Consumindo Mensagens ###");

		while (true) {

			ConsumerRecords<String, Example> records = consumer.poll(1000);

			for (ConsumerRecord<String, Example> record : records) {
				Example customer = record.value();
				System.out.println(customer);

				logger.info("Key: " + record.key() + ", Value: " + record.value());
				logger.info("Partition: " + record.partition() + ", Offset: " + record.offset());
			}

			consumer.commitSync();
		}
	}
}
