package test.br.com.itau.jp7.orq.producer;

import br.com.itau.cert.client.CertClientManager;
import br.com.itau.cert.client.enums.Environment;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.itau.ikafka.clients.producer.IKafkaAcksType;
import br.com.itau.ikafka.clients.producer.IKafkaCompressionType;
import br.com.itau.ikafka.clients.producer.IKafkaProducerBuilder;
import br.com.itau.kafka.avro.Example;
import io.confluent.kafka.serializers.KafkaAvroSerializer;

import java.time.LocalDateTime;
import java.util.UUID;

public class ProducerApp {

	private static Logger logger = LoggerFactory.getLogger(Producer.class.getName());

	public static void main(String[] args) {
		CertClientManager.Builder()
						.withCertClientUser("JP70001")
						.withCertClientPassword("kcert-password")
						.withEnvironment(Environment.SANDBOX)
						.withAppName("java-ikafka-producer-consumer-native")
						.withKeyStoreLocation("C:Usersrodnetoitauestrategiasrecupcredito-orquestradoracoesappJP70001")
						.withKeyStorePassword("gAAAAABgp8B2a7Z_thBIxM21p235iTknnSfbf4MDlejvcKFAGPcUcMU_ymz8kvk7GUk4JAlqONTKRLmMKGhzSzi2BPbgHGgMPg==")
						.withTrustStoreLocation("C:Usersrodnetoitauestrategiasrecupcredito-orquestradoracoesappJP70001.truststore.jks")
						.withTrustStorePassword("gAAAAABgp8B2a7Z_thBIxM21p235iTknnSfbf4MDlejvcKFAGPcUcMU_ymz8kvk7GUk4JAlqONTKRLmMKGhzSzi2BPbgHGgMPg==")
						.withCommunity("Teste")
						.withSigla("EA3")
						.build().run();

		Producer<String, Example> producer = IKafkaProducerBuilder.<String, Example>newBuilder()
				.withBootstrapServers("kafka-events.dev.aws.cloud.ihf:31101")
				.withAcks(IKafkaAcksType.ALL)
				.withKeySerializerClass(StringSerializer.class.getName())
				.withValueSerializerClass(KafkaAvroSerializer.class.getName())
				.withBatchSize(65536)
				.withLingerMs(50)
				.withCompressionType(IKafkaCompressionType.LZ4)
				.withEnableIdempotence(true)
				.withClientId("test-id")
				.withSslSecurityProtocol("SSL")
				.withSslKeystoreLocation("C:Usersrodnetoitauestrategiasrecupcredito-orquestradoracoesappJP70001")
				.withSslKeystorePassword("gAAAAABgp8B2a7Z_thBIxM21p235iTknnSfbf4MDlejvcKFAGPcUcMU_ymz8kvk7GUk4JAlqONTKRLmMKGhzSzi2BPbgHGgMPg==")
				.withSslKeyPassword("gAAAAABgp8B2a7Z_thBIxM21p235iTknnSfbf4MDlejvcKFAGPcUcMU_ymz8kvk7GUk4JAlqONTKRLmMKGhzSzi2BPbgHGgMPg==")
				.withSslTruststoreLocation("C:Usersrodnetoitauestrategiasrecupcredito-orquestradoracoesappJP70001.truststore.jks")
				.withSslTruststorePassword("gAAAAABgp8B2a7Z_thBIxM21p235iTknnSfbf4MDlejvcKFAGPcUcMU_ymz8kvk7GUk4JAlqONTKRLmMKGhzSzi2BPbgHGgMPg==")
				.withAutoRegisterSchemas(false)
				.withSchemaRegistryUrl("https://kafka-events-schema-registry.dev.aws.cloud.ihf:8082")
				.withValueSubjectNameStrategy("io.confluent.kafka.serializers.subject.TopicRecordNameStrategy")
				.withSchemaRegistryReuseSslKeystoreConfigFromIKafka(true)
				.withSchemaRegistryReuseSslTruststoreConfigFromIKafka(true)
				.build();

		String topic = "recuperacao-de-credito-comando-enviar-distribuicao-escritorio-recuperacao-credito";
		// Avro Object
		@SuppressWarnings("static-access")
		Example example = Example.newBuilder()
						.setId("1")
						.setName("Jedd Ellison")
						.build();

		ProducerRecord<String, Example> producerRecord = new ProducerRecord<>(topic, example);
		producerRecord.headers().add(new RecordHeader("specversion", "undefined specversion".getBytes()));
		producerRecord.headers().add(new RecordHeader("eventversion", "undefined eventversion".getBytes()));
		producerRecord.headers().add(new RecordHeader("type", "undefined type".getBytes()));
		producerRecord.headers().add(new RecordHeader("time", LocalDateTime.now().toString().getBytes()));
		producerRecord.headers().add(new RecordHeader("source", "undefined source".getBytes()));
		producerRecord.headers().add(new RecordHeader("transactionid", UUID.randomUUID().toString().getBytes()));
		producerRecord.headers().add(new RecordHeader("id", "undefined id".getBytes()));
		producerRecord.headers().add(new RecordHeader("datacontenttype", "undefined datacontenttype".getBytes()));

		producer.send(producerRecord, new Callback() {
			@Override
			public void onCompletion(RecordMetadata metadata, Exception exception) {
				if (exception == null) {
					logger.info("### Produzindo Mensagens ###");
					logger.info(metadata.toString());
				} else {
					exception.printStackTrace();
				}
			}
		});
		producer.flush();
		producer.close();
	}
}