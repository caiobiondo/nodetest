# iKafka - Producer and Consumer native: Projeto

###### Ferramentas

* JDK 1.8+

* Apache Maven 3.3.9+

###### Comando para gerar pojo.
```shell
mvn generate-resources
```

###### Comando para gerar pacote.
```shell
mvn packge
```