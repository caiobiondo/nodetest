package io.healthcheck.ApiwebkotlinApplication

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class ApiwebkotlinApplication

fun main(args: Array<String>) {
	runApplication<ApiwebkotlinApplication>(*args)
}
